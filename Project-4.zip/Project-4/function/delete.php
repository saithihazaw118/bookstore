<?php 
session_start();

include "connection.php";



$cusID=$_GET['cusID'];
$delete = "DELETE FROM tbl_customer WHERE cusID='$cusID' ";
$result = mysqli_query($connection,$delete);

    echo "<script>window.alert('User Delete!')</script>";
    echo "<script>window.location='../approvenedit.php'</script>";

?>