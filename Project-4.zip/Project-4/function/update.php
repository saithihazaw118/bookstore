<?php 
	session_start();
	include "connection.php";


$cusID = $_GET['cusID'];
// $_GET['Name'];
// $_GET['Address'];
// $_GET['ContactNo'];
// $_GET['Email'];

if(isset($_GET['update']))
{
    $cusID=$_GET['cusID'];
    $cusName=$_GET['name'];
    $address=$_GET['address'];
    $contactno=$_GET['contactno'];
    $email=$_GET['email'];

    $query = "UPDATE tbl_customer SET Name='$cusName',
                                        Address='$address',
                                        ContactNo='$contactno',
                                        Email='$email'
                                        WHERE cusID='$cusID' ";

    $data=mysqli_query($connection,$query);
    if ($data)
    {
      echo "<script>window.alert('Update Successful')</script>";
     echo "<script>window.location='../approvenedit.php'</script>";
    }  

   else
   {
      echo "<font color='red'>Update Failed,Try Again </font> ";
   }
   

 }

?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>User Update Page</title> 
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
     <!-- Custom Css -->
    <link rel="stylesheet" type="text/css" href="../css/style.css"> 
</head>
<body>
<!-- <nav class="navbar_sec">
	<header data-text="Admin_Home" class="admin-text">Admin Home</header>
	<ul class="ul-sec">
		<li class="li-sec"> <a href="../approvenedit.php" class="nav-link">Approve</a>  </li>
		<li class="li-sec"> <a href="../addproduct.php" class="nav-link">Add Product</a> </li>
		<li class="li-sec"> <a href="../productdatatable.php" class="nav-link">View Product</a> </li>
		<li class="li-sec"> <a href="../addgenre.php" class="nav-link">Add Genre</a> </li>
		<li class="li-sec"> <a href="../login.php" class="nav-link">Logout</a> </li>
	</ul>
</nav> -->

<main id="main-doc">
	<section class="main-section" id="Introduction">
   
    <div class="center"> 
    
<form action="update.php" method="GET" enctype="multipart/form-data">
   <div class="text-center text-primary mt-3">
   <h1>Update Form</h1>
   </div>

   <input type="text" hidden name="cusID" value="<?php echo $_GET['cusID']; ?>">

   <div class="form-group mb-3">
        <label for="name">Name:</label>
        <input type="text" name="name" value="<?php echo $_GET['Name']; ?>" class="form-control" autofocus>
        <div class="error text-danger"></div>
    </div>
    <div class="form-group mb-3">
        <label for="address">Address:</label>
        <textarea name="address" cols="30" rows="3" class="form-control"><?php echo $_GET['Address']; ?></textarea>
        <div class="error text-danger"></div>
    </div>
    <div class="form-group mb-3">
        <label for="contactno">Contact No:</label>
       <input name="contactno" type="tel"  value="<?php echo $_GET['ContactNo']; ?>" class="form-control">
       <div class="error text-danger"></div>
    </div>
    <div class="form-group mb-3">
        <label for="email">Email:</label>
        <input type="email" name="email" value="<?php echo $_GET['Email']; ?>" class="form-control">
        <div class="error text-danger"></div>
    </div>
   
    <div class="form-group mb-3">
        <button type="submit" name="update" class="btn btn-outline-primary form-control"><i class="fa-solid fa-arrow-right-to-bracket"></i> Update</button>
    </div>
    <hr>
    <div class="form-group text-center">
        <a href="../approvenedit.php"><p>Back</p></a>
    </div>
</form>

        </div>

	</section>
</main>


</body>
</html>



