<?php 
session_start();

include "connection.php";

$cusID=$_GET['cusID'];
$update = "UPDATE tbl_customer SET status = 'approved' WHERE cusID='$cusID' ";
$result = mysqli_query($connection,$update);

    echo "<script>window.alert('User Approved!')</script>";
    echo "<script>window.location='../approvenedit.php'</script>";

?>


