<?php

session_start();

include "connection.php";
$productID=$_GET['productID'];
$delete = "DELETE FROM tbl_book WHERE productID='$productID' ";
$result = mysqli_query($connection,$delete);

    echo "<script>window.alert('Product Delete!')</script>";
    echo "<script>window.location='../editproduct.php'</script>";
    ?>