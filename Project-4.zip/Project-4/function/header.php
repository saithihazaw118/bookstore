<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bookstore</title>
    <!-- Bootstrap css -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <!-- Fontawesome cdn -->
    <script src="https://kit.fontawesome.com/352c72ca99.js" crossorigin="anonymous"></script>
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/styles1.css">
    <!-- Site Logo -->
    <link rel="icon" href="../images/logo1.ico">
      <!-- js -->
 <script defer src="js/script.js"></script>
    <!-- JQuery CDN -->
     <!-- JQuery CDN -->
     <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <!-- Data tabel CDN -->
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">
    <!-- Data table  -->
    <script>
      $(document).ready(function() {
    $('#productTable').DataTable();
} );
    </script>
  
</head>

<body>
   

<?php 

    if (isset($_SESSION['Email']))
{
    echo "
    <nav class='navbar navbar-expand-lg navbar-light bg-light'>
        <div class='container-fluid'>
            <a class='navbar-brand' href='index.html'><img src='images/logo.png' class='img-responsive'></a>
            <button class='navbar-toggler' type='button' data-bs-toggle='collapse'
                data-bs-target='#navbarSupportedContent' aria-controls='navbarSupportedContent' aria-expanded='false'
                aria-label='Toggle navigation'>
                <span class='navbar-toggler-icon'></span>
            </button>

            <div class='collapse navbar-collapse' id='navbarSupportedContent'>
                <ul class='navbar-nav mx-auto mb-2 mb-lg-0'>
                    <li class='nav-item'>
                        <a class='nav-link active' aria-current='page' href='index.html'>Home</a>
                    </li>
                    <li class='nav-item'>
                        <a class='nav-link' href='about.php'>About Us</a>
                    </li>
                    <li class='nav-item'>
                        <a class='nav-link' href='category.php'>Category</a>
                    </li>
                    <li class='nav-item'>
                        <a class='nav-link' href='Contact.php'>Contact Us</a>
                    </li>
                </ul>
                <div class='nav-info'>
                    <ul class='navbar-nav mx-auto mb-2 mb-lg-0'>
                        <li class='nav-item'>
                            <a href='orderHistory.php'><i class='fa-solid fa-arrow-right-from-bracket' aria-hidden='true'>My Order</i></a>
                        </li>
                        <li class='nav-item'>
                            <a href='login.php'><i class='fa-solid fa-arrow-right-from-bracket' aria-hidden='true'> Logout</i></a>
                        </li>
                        <li class='nav-item'>
                            <a href='cart.php'><i class='fa fa-shopping-cart' aria-hidden='true'> Cart</i></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </nav> ";
}else {
    echo "
    <nav class='navbar navbar-expand-lg navbar-light bg-light'>
    <div class='container-fluid'>
        <a class='navbar-brand' href='index.html'><img src='images/logo.png' class='img-responsive'></a>
        <button class='navbar-toggler' type='button' data-bs-toggle='collapse'
            data-bs-target='#navbarSupportedContent' aria-controls='navbarSupportedContent' aria-expanded='false'
            aria-label='Toggle navigation'>
            <span class='navbar-toggler-icon'></span>
        </button>

        <div class='collapse navbar-collapse' id='navbarSupportedContent'>
            <ul class='navbar-nav mx-auto mb-2 mb-lg-0'>
                <li class='nav-item'>
                    <a class='nav-link active' aria-current='page' href='index.html'>Home</a>
                </li>
                <li class='nav-item'>
                    <a class='nav-link' href='about.php'>About Us</a>
                </li>
                <li class='nav-item'>
                    <a class='nav-link' href='category.php'>Category</a>
                </li>
                <li class='nav-item'>
                    <a class='nav-link' href='Contact.php'>Contact Us</a>
                </li>
            </ul>
            <div class='nav-info'>
                <ul class='navbar-nav mx-auto mb-2 mb-lg-0'>
                    <li class='nav-item'>
                        <a href='login.php'><i class='fa fa-user' aria-hidden='true'> Login</i></a>
                    </li>
                    <li class='nav-item'>
                        <a href='cart.php'><i class='fa fa-shopping-cart' aria-hidden='true'> Cart</i></a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</nav> ";
}


?>