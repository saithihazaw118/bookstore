<?php
	session_start();
	include "function/connection.php"; 
		
if(isset($_POST['btnsubmit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $subject = $_POST['subject'];
	  $message = $_POST['message'];
	

        $btnsubmit	 = "INSERT INTO tbl_query(tblName, tblEmail, tblSubject, tblMessage)
        VALUES ('$name','$email','$subject','$message')";
        $result1 =  mysqli_query($connection,$btnsubmit);

        if ($result1) 
        {
			echo "<script>window.alert('Successful')
			window.location='contact.php'</script>";
   		}
      else
       {
         mysqli_error($connection);
       }

    }


	?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bookstore</title>

    <link rel="shortcut icon" href="./images/favicon.ico" type="image/x-icon">
    <!-- bootstrap css -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <!-- fontawesome css -->
    <script src="https://kit.fontawesome.com/352c72ca99.js" crossorigin="anonymous"></script>
    <!-- custom css -->
    <link rel="stylesheet" href="css/style.css">

</head>
<body>

    
<nav class="navbar navbar-expand-lg navbar-light bg-light">
      <div class="container-fluid">
          <a class="navbar-brand" href="index.html"><img src="images/logo.png" class="img-responsive" alt=""></a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
              data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
              aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
          </button>

          <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
                  <li class="nav-item">
                      <a class="nav-link active" aria-current="page" href="index.html">Home</a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link" href="about.php">About Us</a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link" href="category.php">Category</a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link" href="Contact.php">Contact Us</a>
                  </li>
              </ul>
              <div class="nav-info">
                  <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
                      <li class="nav-item">
                          <a href="login.php"><i class="fa fa-user" aria-hidden="true"> Login</i></a>
                      </li>
                      <li class="nav-item">
                          <a href="cart.php"><i class="fa fa-shopping-cart" aria-hidden="true"> Cart</i></a>
                      </li>
                  </ul>
              </div>
          </div>
      </div>
  </nav>



    <section>

      <!-- contact us section -->

      <div class="contact-us">

        <h2>Contact Us</h2>

        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3021.592801155794!2d-73.96944948459323!3d40.77097997932563!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c258ece4fc1cdb%3A0xfdb2873329cdd643!2s890%205th%20Ave%2C%20New%20York%2C%20NY%2010021%2C%20USA!5e0!3m2!1sen!2smm!4v1649780247574!5m2!1sen!2smm" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

        <div class="container">

          <div class="contact-us-form">

            <h1>Contact Information</h1>
            <p> <span> We will answer any questions you may have about our online sales, rights or partnership service right here </span> </p>
            <div class="social-media">
              <h5>Socail Media</h5>
              <ul>
                <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                <li><a href="#"><i class="fa fa-youtube" aria-hidden="true"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                <li><a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
              </ul>
            </div>

            <h1>Get In Touch</h1>
<form  action="contact.php" method="POST" enctype="multipart/form-data">
            <div class="top-form">

              <div class="inner-form">
                <label for="name">Name</label>
                <input name="name" type="text" placeholder="">
              </div>
              <div class="inner-form">
                <label for="email">Email</label>
                <input name="email" type="email" placeholder="">
              </div>
  
            </div>
  
            <div class="middle-form">
              <label for="subject">Subject</label>
              <div>
                <select name="subject" id="" class="form-control form-select select">
                  <option required = "---Select Option---">---Select Option---</option>
                  <option value="For_Error">For Error</option>
                  <option value="For_Advice">For Advice</option>
                </select>
              </div>
            </div>
  
            <div class="bottom-form">
              <label for="message">Details please! Your review helps other shoppers.</label>
              <textarea name="message" id="" placeholder="What did you like or dislike? What should other shoppers know before buying?"></textarea>
            </div>
  
            <button type="submit" name="btnsubmit">Submit Message</button>
  </form>
          </div>
  
  
          </div>

        </div>
        

      </div>

      <!-- contact us section -->

    </section>


    
    <footer>

      <!-- footer section -->

      <div class="subscription">

        <h1>Join Our Newsletter</h1>
        <p>Signup to be the first to hear about exclusive deals, special offers and upcoming collections</p>
        <input type="email" name="" id="" placeholder="Enter email for weekly newsletter.">
        <button type="submit">Subscribe</button>

      </div>

      <div class="footer-menu d-lg-flex d-md-block d-sm-block">

        <div class="footer-menu-1">
          <img src="./images/bookstore-logo.png" alt="..." width="255">
          <p>890 Fifth Avenue, Manhattan, New York City, United States</p>
          <a href="mailto:bookstore@gmail.com">sale@bookstore.com</a>
          <a href="tel:+12345678901">+1 234-567-8901</a>
          <ul>
            <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fa fa-youtube" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
          </ul>
        </div>

        <div class="footer-menu-2">

          <h4>Explore</h4>
          <a href="#">About us</a>
          <a href="#">Sitemap</a>
          <a href="#">Bookmarks</a>
          <a href="#">Sign in/Join</a>

        </div>

        <div class="footer-menu-2">

          <h4>Customer Service</h4>
          <a href="#">Help Center</a>
          <a href="#">Returns</a>
          <a href="#">Product Recalls</a>
          <a href="#">Accessibility</a>
          <a href="#">Contact Us</a>
          <a href="#">Store Pickup</a>
          
        </div>

        <div class="footer-menu-2">

          <h4>Policy</h4>
          <a href="#">Return Policy</a>
          <a href="#">Terms Of Use</a>
          <a href="#">Security</a>
          <a href="#">Privacy</a>
          
        </div>

        <div class="footer-menu-2">

          <h4>Categories</h4>
          <a href="#">Action</a>
          <a href="#">Comedy</a>
          <a href="#">Drama</a>
          <a href="#">Horror</a>
          <a href="#">Kids</a>
          
        </div>

      </div>

      <div class="footer-bottom">
  
        <p>©2022 Bookstore. All rights reserved</p>
        <ul>  
          <li> <img src="./images/clients/mastercard.png" alt="..." width="50"> </li>
          <li> <img src="./images/clients/paypal.png" alt="..." width="50"> </li>
          <li> <img src="./images/clients/skrill.png" alt="..." width="50"> </li>
          <li> <img src="./images/clients/visa.png" alt="..." width="50"> </li>
          <!-- <img src="" alt="..."> -->
        </ul>

      </div>

      <!-- footer section -->

    </footer>


    <!-- custom js -->
    <script src="js/index.js"></script>
    <!-- bootstrap js -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>
</html>