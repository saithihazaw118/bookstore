<?php
    include("function/header.php");
?>

<div class="container">
<form action="action.php" method="POST" id="loginForm">
   <div class="text-center text-primary mt-3">
   <h1>Login Form</h1>
   </div>
    <div class="form-group mb-3">
        <label for="Email">Email:</label>
        <input type="email" name="Email" placeholder="Enter email address" class="form-control" autofocus required>
    </div>
    <div class="form-group mb-3">
        <label for="Password">Password:</label>
        <input type="Password" name="Password" placeholder="Enter Password" class="form-control" required>
    </div>
    <div class="form-group mb-3">
        <button type="submit" name="btnLogin" class="btn btn-outline-primary form-control"><i class="fa-solid fa-arrow-right-to-bracket"></i> Login</button>
    </div>
    <hr>
    <div class="form-group text-center">
       <p>Dont have an account ? Register <a href="register.php">HERE</a></p>
    </div>
</form>
</div>
<?php
    include("function/footer.php");
?>