<?php
	session_start();
	include "function/connection.php"; 
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Eidt User Page</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<!-- Custom Css -->
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<nav id="navbar">
	<header data-text="Admin_Home" class="admin-text">Admin Home</header>
	<ul>
		<li> <a href="approvenedit.php" class="nav-link">Approve</a>  </li>
		<li> <a href="addproduct.php" class="nav-link">Add Product</a> </li>
		<li> <a href="productdatatable.php" class="nav-link">View Product</a> </li>
		<li> <a href="addgenre.php" class="nav-link">Add Genre</a> </li>
		<li class="li-sec"> <a href="query.php" class="nav-link">Query</a> </li>
		<li> <a href="login.php" class="nav-link">Logout</a> </li>
	</ul>
</nav>
<main id="main-doc">
	

	<section class="main-section" id="Hello_World">
		<header><h2>Edit User</h2></header>

		<?php
	$query="SELECT * FROM tbl_customer WHERE status = 'approved'";
	$data=mysqli_query($connection,$query);
 	$total=mysqli_num_rows($data); 


		   if ($total !=0) 
 		{
 			?>

 		<table class="table1">
		<tr class="tr1" style="text-align: center;">
 			<th class="th1">Customer Name</th>
			 <th class="th1">Address</th>
			 <th class="th1">Contact No</th>
 			<th class="th1">Email</th>
			<th class="th1" colspan="2">Action</th>
 		</tr>

 		<?php 

 		while ($result=mysqli_fetch_assoc($data))
			 {

 			echo " 
 			<tr class = 'tr1';>
 						<td>".$result['Name']."</td>
 						<td>".$result['Address']."</td>
						 <td>".$result['ContactNo']."</td>
 						<td>".$result['Email']."</td>
						 <td><a href='update.php?cusID=$result[cusID] & 
						 Name=$result[Name] &
						 Address=$result[Address] &
						 ContactNo=$result[ContactNo] &
						 Email=$result[Email]'>Update</a></td>

						 <td> <a href='delete.php?cusID=$result[cusID] & 
						 Name=$result[Name] &
						 Address=$result[Address] &
						 ContactNo=$result[ContactNo] &
						 Email=$result[Email]'>Delete</a></td>

						
 						
 				</tr>  " ;
 		}

 	}
	?>
	</table>
 	
	</section>

</main>
</body>
</html>