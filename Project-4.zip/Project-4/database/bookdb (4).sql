-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8111
-- Generation Time: Apr 22, 2022 at 03:53 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bookdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `adminID` int(11) NOT NULL,
  `adminName` varchar(255) NOT NULL,
  `adminEmail` varchar(255) NOT NULL,
  `adminPassword` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`adminID`, `adminName`, `adminEmail`, `adminPassword`) VALUES
(2, 'Admin Two', 'admintwo@gmail.com', '5588cb33a7361470d0bd5302143e8c18');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_book`
--

CREATE TABLE `tbl_book` (
  `productID` int(11) NOT NULL,
  `bookTitle` varchar(255) NOT NULL,
  `Image` text NOT NULL,
  `Price` float(10,2) NOT NULL,
  `genreID` int(11) NOT NULL,
  `ISBN` varchar(255) NOT NULL,
  `Author` varchar(255) NOT NULL,
  `Publisher` varchar(255) NOT NULL,
  `Summary` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_book`
--

INSERT INTO `tbl_book` (`productID`, `bookTitle`, `Image`, `Price`, `genreID`, `ISBN`, `Author`, `Publisher`, `Summary`) VALUES
(23, 'Will You Stay?', 'images/willyoustay.jpg', 30.00, 15, '9789672459132', 'Norhafsah Hamid', 'Iman Publication', '“If you love Allah and take care of your relationship with Him, He will take care of the people whom you love.\"\r\n\r\nAmy is a 30-year-old doctor who strives to live a meaningful life, choosing to focus on enjoying the company of her friends and committed in nurturing her faith. The unexpected presence of someone from her friend’s past stirs up feelings within her. What she was afraid to dream of before this, presented itself to her like a ray of hope from God.\r\n\r\nJust as her newfound happiness begin to colour her life, her faith is put to the test. Will love stay or will it leave? Will she surrender herself to the One whose love is eternal? In this book, award-winning author Norhafsah Hamid takes reader on a heart-warming journey of understanding what it means to love compassionately and with mercy. For that is the kind of love that will lead us back to God.'),
(24, 'The Greatest Secret (UK) ', 'images/thegreatestscret.jpg', 89.90, 15, '9780008447373 ', 'Byrne, Rhonda ', 'Harper UK ', 'Once you know, freedom is yours.The Greatest Secret, the long-awaited major work by Rhonda Byrne, lays out the next quantum leap in a journey that will take the reader beyond the material world and into the spiritual realm, where all possibilities exist. The book reflects Rhonda'),
(25, 'The Hobbit ', 'images/51B9ZIPwB9L._SL350_.jpg', 56.99, 15, '0618260307 ', ' J.R.R. Tolkien, Christopher Tolkien, Alan Lee ', 'Houghton Mifflin ', 'A great modern classic and the prelude to The Lord of the Rings. Bilbo Baggins is a hobbit who enjoys a comfortable, unambitious life, rarely traveling any farther than his pantry or cellar. But his contentment is disturbed when the wizard Gandalf and a company of dwarves arrive on his doorstep one day to whisk him away on an adventure. They have launched a plot to raid the treasure hoard guarded by Smaug the Magnificent, a large and very dangerous...'),
(26, 'Squire ', 'images/squire.jpg', 45.99, 15, '9780375829062 ', 'Tamora Pierce ', 'Random House Children', '<br /><b>Notice</b>:  Undefined index: Summary in <b>C:xampphtdocsProject-4productedit.php</b> on line <b>186</b><br />'),
(27, 'Count Your Lucky Stars ', 'images/count.jpg', 67.99, 15, '9780063000889 ', 'Alexandria Bellefleur ', 'HarperCollins Publishers ', 'Margot Cooper doesn'),
(28, 'In the Dust of This Planet ', 'images/hor.jpg', 12.99, 15, '9781846946769 ', 'Eugene Thacker ', 'Hunt Publishing Limited, John ', ''),
(30, 'Spear', 'images/9781250819321.jpg', 19.99, 17, '9781250819321', 'Nicola Griffith', 'TORDOTCOM', 'She grows up in the wild wood, in a cave with her mother, but visions of a faraway lake drift to her on the spring breeze, scented with promise. And when she hears a traveler speak of Artos, king of Caer Leon, she decides her future lies at his court. So, brimming with magic and eager to test her strength, she breaks her covenant with her mother and sets out on her bony gelding for Caer Leon.'),
(31, 'Passersthrough', 'images/9781641293433.jpg', 26.00, 16, '97812508193219781641293433', 'Peter Rock', 'SOHO PRESS', 'Passersthrough is a gripping, slippery, spooky book about fragile family bonds, loneliness, and what we choose to remember. A welcome return from Peter Rock, this is a thoroughly Oregon book — filled with mountains, forests, lakes, and creatures. Recommended By Kelsey F., Powells.com');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cart`
--

CREATE TABLE `tbl_cart` (
  `cartID` int(11) NOT NULL,
  `cusID` int(11) NOT NULL,
  `productID` int(11) NOT NULL,
  `bookTitle` text NOT NULL,
  `Image` text NOT NULL,
  `Price` float(10,2) NOT NULL,
  `Payment` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_cart`
--

INSERT INTO `tbl_cart` (`cartID`, `cusID`, `productID`, `bookTitle`, `Image`, `Price`, `Payment`) VALUES
(1, 14, 24, 'The Greatest Secret (UK)', '../images/thegreatestscret.jpg', 89.90, 'Paid'),
(4, 14, 27, 'Count Your Lucky Stars', '../images/count.jpg', 67.99, 'Paid'),
(5, 14, 26, 'Squire', '../images/squire.jpg', 45.99, 'Paid'),
(8, 14, 28, 'In the Dust of This Planet', '../images/hor.jpg', 12.99, 'Paid'),
(11, 15, 23, 'Will You Stay?', '../images/willyoustay.jpg', 30.00, 'Paid'),
(12, 15, 24, 'The Greatest Secret (UK)', '../images/thegreatestscret.jpg', 89.90, 'Paid'),
(16, 15, 28, 'In the Dust of This Planet ', 'images/hor.jpg', 12.99, 'Paid'),
(18, 15, 27, 'Count Your Lucky Stars ', 'images/count.jpg', 67.99, 'Paid'),
(21, 15, 26, 'Squire ', 'images/squire.jpg', 45.99, 'Paid');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE `tbl_customer` (
  `cusID` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Address` text NOT NULL,
  `ContactNo` varchar(30) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Status` varchar(255) NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`cusID`, `Name`, `Address`, `ContactNo`, `Email`, `Password`, `Status`) VALUES
(14, 'Book User Two', '858 Oak Street', '315-324-0198', 'bookusertwo@gmail.com', 'c2c64949e4dbcf57b9809af4f990d3d9', 'Approved'),
(15, 'User Three', '3856 West Fork Drive', '954-464-0600', 'userthree@gmail.com', '1de54ee388d9bf255d32ae997b82e32c', 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_genre`
--

CREATE TABLE `tbl_genre` (
  `genreID` int(11) NOT NULL,
  `genre` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_genre`
--

INSERT INTO `tbl_genre` (`genreID`, `genre`) VALUES
(13, 'Horror'),
(14, 'Romance'),
(15, 'Fiction'),
(16, 'Non-Fiction'),
(17, 'Novel');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `orderID` int(11) NOT NULL,
  `cusID` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Address` text NOT NULL,
  `ContactNo` varchar(30) NOT NULL,
  `total_item` int(30) NOT NULL,
  `total_price` float(10,2) NOT NULL,
  `payment_type` varchar(30) NOT NULL,
  `card_no` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`orderID`, `cusID`, `Name`, `Address`, `ContactNo`, `total_item`, `total_price`, `payment_type`, `card_no`) VALUES
(1, 14, 'Book User Two', '858 Oak Street', '315-324-0198', 3, 203.88, 'Master', '1234123412341234'),
(2, 15, 'User Three', '3856 West Fork Drive', '954-464-0600', 1, 30.00, 'Master', '4321431243212411'),
(3, 15, 'User Three', '3856 West Fork Drive', '954-464-0600', 1, 30.00, 'Visa', '1234123412341234'),
(4, 15, 'User Three', '3856 West Fork Drive', '954-464-0600', 1, 89.90, 'Visa', '4321431243212411'),
(5, 15, 'User Three', '3856 West Fork Drive', '954-464-0600', 3, 126.97, 'Master', '1212121212121212');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_query`
--

CREATE TABLE `tbl_query` (
  `ID` int(11) NOT NULL,
  `tblName` varchar(50) NOT NULL,
  `tblEmail` varchar(50) NOT NULL,
  `tblSubject` varchar(255) NOT NULL,
  `tblMessage` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_query`
--

INSERT INTO `tbl_query` (`ID`, `tblName`, `tblEmail`, `tblSubject`, `tblMessage`) VALUES
(1, 'sai', 'sai@gmail.com', 'For_Error', 'There have padding error in the first page.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`adminID`),
  ADD UNIQUE KEY `adminEmail` (`adminEmail`);

--
-- Indexes for table `tbl_book`
--
ALTER TABLE `tbl_book`
  ADD PRIMARY KEY (`productID`),
  ADD KEY `genreID` (`genreID`);

--
-- Indexes for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  ADD PRIMARY KEY (`cartID`),
  ADD KEY `cusID` (`cusID`),
  ADD KEY `productID` (`productID`);

--
-- Indexes for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  ADD PRIMARY KEY (`cusID`),
  ADD UNIQUE KEY `cusEmail` (`Email`),
  ADD UNIQUE KEY `ContactNo` (`ContactNo`);

--
-- Indexes for table `tbl_genre`
--
ALTER TABLE `tbl_genre`
  ADD PRIMARY KEY (`genreID`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`orderID`),
  ADD KEY `cusID` (`cusID`);

--
-- Indexes for table `tbl_query`
--
ALTER TABLE `tbl_query`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `adminID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_book`
--
ALTER TABLE `tbl_book`
  MODIFY `productID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  MODIFY `cartID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  MODIFY `cusID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `tbl_genre`
--
ALTER TABLE `tbl_genre`
  MODIFY `genreID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `orderID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_query`
--
ALTER TABLE `tbl_query`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_book`
--
ALTER TABLE `tbl_book`
  ADD CONSTRAINT `tbl_book_ibfk_1` FOREIGN KEY (`genreID`) REFERENCES `tbl_genre` (`genreID`),
  ADD CONSTRAINT `tbl_book_ibfk_2` FOREIGN KEY (`genreID`) REFERENCES `tbl_genre` (`genreID`),
  ADD CONSTRAINT `tbl_book_ibfk_3` FOREIGN KEY (`genreID`) REFERENCES `tbl_genre` (`genreID`);

--
-- Constraints for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  ADD CONSTRAINT `tbl_cart_ibfk_1` FOREIGN KEY (`cusID`) REFERENCES `tbl_customer` (`cusID`),
  ADD CONSTRAINT `tbl_cart_ibfk_2` FOREIGN KEY (`productID`) REFERENCES `tbl_book` (`productID`);

--
-- Constraints for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD CONSTRAINT `tbl_order_ibfk_1` FOREIGN KEY (`cusID`) REFERENCES `tbl_customer` (`cusID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
