    <?php
	session_start();
	include "function/connection.php"; 
?>

<!DOCTYPE html>
<html lang="en"> 
<head>
  <title>Admin Approve and Edit Page</title> 
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
 <!-- Custom Css -->
 <link rel="stylesheet" type="text/css" href="css/style.css"> 
</head>
<body>
<nav class="navbar_sec">
	<header data-text="Admin_Home" class="admin-text">Admin Home</header>
	<ul class="ul-sec">
		<li class="li-sec"> <a href="approvenedit.php" class="nav-link">Approve</a>  </li>
		<li class="li-sec"> <a href="addproduct.php" class="nav-link">Add Product</a> </li>
		<li class="li-sec"> <a href="productdatatable.php" class="nav-link">View Product</a> </li>
		<li class="li-sec"> <a href="addgenre.php" class="nav-link">Add Genre</a> </li>
        <li class="li-sec"> <a href="query.php" class="nav-link">Query</a> </li>
		<li class="li-sec"> <a href="login.php" class="nav-link">Logout</a> </li>
	</ul>
</nav>

<main id="main-doc">
	<section class="main-section" id="Introduction">
		<header><h2>Advice From The Customer</h2></header>
		<div class="forscrollbar" style="right:10%;">
		<table class="text-center conpact table-stripped table1">
			<tr class="tr1">
                <th class="th1">ID</th>
				<th class="th1">Customer Name</th>
				<th class="th1">Email</th>
				<th class="th1">Subject</th>
				<th class="th1">Message</th>
			</tr>
		

			<?php
				$sqlimage  = "SELECT * FROM tbl_query";
				$imageresult1 = mysqli_query($connection,$sqlimage);
				
				while($rows=mysqli_fetch_assoc($imageresult1))
				{	
					$ID = $rows['ID'];
					$tblName = $rows['tblName'];
					$tblEmail = $rows['tblEmail'];
					$tblSubject = $rows['tblSubject'];
					$tblMessage = $rows['tblMessage'];

					echo "<tr class = 'tr1';>";
					echo "<td>$ID</td>";
                    echo "<td>$tblName</td>";
					echo "<td>$tblEmail</td>";
					echo "<td>$$tblSubject</td>";
					echo "<td>$tblMessage</td>";
					echo "</tr>";

				} 
			?>
		</div>
		</table>
	</section>

</main>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</body>
</html>