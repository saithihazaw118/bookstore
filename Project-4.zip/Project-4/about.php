<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bookstore</title>

    <link rel="shortcut icon" href="./images/favicon.ico" type="image/x-icon">
    <!-- bootstrap css -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <!-- custom css -->
    <link rel="stylesheet" href="css/style.css">
    <!-- fontawesome css -->
    <script src="https://kit.fontawesome.com/352c72ca99.js" crossorigin="anonymous"></script>

</head>
<body>

    
<nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.html"><img src="images/logo.png" class="img-responsive" alt=""></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="index.html">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php">About Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="category.php">Category</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Contact.php">Contact Us</a>
                    </li>
                </ul>
                <div class="nav-info">
                    <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a href="login.php"><i class="fa fa-user" aria-hidden="true"> Login</i></a>
                        </li>
                        <li class="nav-item">
                            <a href="cart.php"><i class="fa fa-shopping-cart" aria-hidden="true"> Cart</i></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>



    <section>

      <!-- about us section -->

      <div class="about-us">
        
        <h2>About Us</h2>

        <img src="./images/devon-divine-Hzp-1ua8DVE-unsplash.jpg" alt="...">

        <div class="container">

          <div class="about-us-form">

            <h1>Welcome to Bookstore</h1>
            <p> <span> “ Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model search for eolved over sometimes by accident, sometimes on purpose ” </span> </p>
            
            <div class="about-box">
              <h4>What we really do?</h4>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse itaque voluptate, assumenda veniam tempora dolores quasi modi aliquam, ut obcaecati sequi enim autem sunt magni accusamus in porro perspiciatis commodi? Qui eaque officia quisquam eius pariatur id, facere enim veniam. Lorem ipsum dolor, sit amet consectetur adipisicing elit. Animi placeat minus, debitis nobis excepturi, omnis recusandae tempore.?</p>
            </div>

            <div class="about-us-text">

              <div class="about-box">
                <h4>Our Vision</h4>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse itaque voluptate, assumenda veniam tempora dolores quasi modi aliquam, ut obcaecati sequi.</p>
              </div>

              <div class="about-box">
                <h4>Our Vision</h4>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse itaque voluptate, assumenda veniam tempora dolores quasi modi aliquam, ut obcaecati sequi.</p>
              </div>

            </div>

          </div>

        </div>

        <div class="users-number">

          <div class="u-n-box">

            <h1>45M</h1>
            <h5>Active Readers</h5>

          </div>

          <div class="u-n-box">

            <h1>+6k</h1>
            <h5>Total Books</h5>

          </div>

          <div class="u-n-box">

            <h1>10M</h1>
            <h5>Buyers Activie</h5>

          </div>

          <div class="u-n-box">

            <h1>283</h1>
            <h5>Cup Of Coffee</h5>

          </div>

        </div>

      </div>

      <div class="about-info">

        <h2>Why We </h2>

        <div class="abt-us-info">

          <div class="info-box">

            <i class="fa fa-truck" aria-hidden="true"></i>
            <h4>Free Delivery</h4>
            <p> Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu. Lorem ipsum dolor sit amet.</p>

          </div>

          <div class="info-box">

            <i class="fa fa-credit-card"></i>
            <h4>Free Delivery</h4>
            <p> Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu. Lorem ipsum dolor sit amet.</p>

          </div>

          <div class="info-box">

            <i class="fa fa-check"></i>
            <h4>Money Back Guarantee</h4>
            <p> Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu. Lorem ipsum dolor sit amet.</p>

          </div>

          <div class="info-box">

            <i class="fa fa-comments"></i>
            <h4>24/7 Support</h4>
            <p> Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu. Lorem ipsum dolor sit amet.</p>

          </div>

        </div>

        <div class="our-team">

          <h2>Our Team </h2>

          <div class="our-team-people">

            <div class="team-box">

              <img src="./images/person.png" alt="">
              <h3>Naing Phyo Thiha</h3>
              <p>Founder</p>
  
            </div>
  
            <div class="team-box">
  
              <img src="./images/person.png" alt="">
              <h3>Sai Thiha Zaw</h3>
              <p>Founder</p>
              
            </div>
            
            <div class="team-box">
              
              <img src="./images/person.png" alt="">
              <h3>Sai Yan Naing</h3>
              <p>Founder</p>
  
            </div>

          </div>
        
        </div>

      </div>

      <!-- about us section -->

    </section>


    
    <footer>

      <!-- footer section -->

      <div class="subscription">

        <h1>Join Our Newsletter</h1>
        <p>Signup to be the first to hear about exclusive deals, special offers and upcoming collections</p>
        <input type="email" name="" id="" placeholder="Enter email for weekly newsletter.">
        <button type="submit">Subscribe</button>

      </div>

      <div class="footer-menu d-lg-flex d-md-block d-sm-block">

        <div class="footer-menu-1">
          <img src="./images/bookstore-logo.png" alt="..." width="255">
          <p>890 Fifth Avenue, Manhattan, New York City, United States</p>
          <a href="mailto:bookstore@gmail.com">sale@bookstore.com</a>
          <a href="tel:+12345678901">+1 234-567-8901</a>
          <ul>
            <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fa fa-youtube" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
          </ul>
        </div>

        <div class="footer-menu-2">

          <h4>Explore</h4>
          <a href="#">About us</a>
          <a href="#">Sitemap</a>
          <a href="#">Bookmarks</a>
          <a href="#">Sign in/Join</a>

        </div>

        <div class="footer-menu-2">

          <h4>Customer Service</h4>
          <a href="#">Help Center</a>
          <a href="#">Returns</a>
          <a href="#">Product Recalls</a>
          <a href="#">Accessibility</a>
          <a href="#">Contact Us</a>
          <a href="#">Store Pickup</a>
          
        </div>

        <div class="footer-menu-2">

          <h4>Policy</h4>
          <a href="#">Return Policy</a>
          <a href="#">Terms Of Use</a>
          <a href="#">Security</a>
          <a href="#">Privacy</a>
          
        </div>

        <div class="footer-menu-2">

          <h4>Categories</h4>
          <a href="#">Action</a>
          <a href="#">Comedy</a>
          <a href="#">Drama</a>
          <a href="#">Horror</a>
          <a href="#">Kids</a>
          
        </div>

      </div>

      <div class="footer-bottom">
  
        <p>©2022 Bookstore. All rights reserved</p>
        <ul>  
          <li> <img src="./images/clients/mastercard.png" alt="..." width="50"> </li>
          <li> <img src="./images/clients/paypal.png" alt="..." width="50"> </li>
          <li> <img src="./images/clients/skrill.png" alt="..." width="50"> </li>
          <li> <img src="./images/clients/visa.png" alt="..." width="50"> </li>
          <!-- <img src="" alt="..."> -->
        </ul>

      </div>

      <!-- footer section -->

    </footer>


    <!-- custom js -->
    <script src="js/index.js"></script>
    <!-- bootstrap js -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>
</html>