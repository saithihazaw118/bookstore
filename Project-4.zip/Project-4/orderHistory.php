
<?php
 include "function/header.php";
 include "function/connection.php";
 if(!isset($_SESSION['Email'])){
    echo"<script>window.alert('Login to Continue');window.location.href='login.php';</script>";
     }


?>
 <div class="container mb-3 mt-3 table-responsive">
   <h1 class="text-center mb-3">My Order History</h1>
 <table class="table table-striped table-bordered text-center "  id="mydatatable">

     <thead>
         <tr >
             <th hidden>Product ID</th>
             <th style="width: 30%;">Order ID</th>
             <th style="width: 30%;">Total Item</th>
             <th style="width: 10%;">Total Price</th>
             <th style="width: 10%;">Payment  Type</th>
             <th style="width: 10%;">Action</th>
         </tr>
     </thead>

     <tbody>

         
     <?php


         $query  = "SELECT * FROM tbl_order";
         $result = mysqli_query($connection,$query);
         

         while($rows=mysqli_fetch_assoc($result))
         {	 $cusID = $rows['cusID'];
             $orderID = $rows['orderID'];
             $totalItem = $rows['total_item'];
             $totalPrice = $rows['total_price'];
             $payment = $rows['payment_type'];

             echo "<tr>";
             echo "<td hidden></td>";
             echo "<td>$orderID</td>";
             echo "<td>$totalItem</td>";

             echo "<td>$totalPrice</td>";
             echo "<td>$payment</td>";
             echo "<td><a href='#' class='btn btn-warning'>Details</a></td> ";
            echo "</tr>";

                                                } 

?>

     </tbody>
     
     <!-- </form> -->



<?php
 include "function/footer.php";
?>