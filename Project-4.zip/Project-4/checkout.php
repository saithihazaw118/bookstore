<?php
 include 'function/header.php';
 include 'function/connection.php';
 session_start();

 if(!isset($_SESSION['Email'])){
    echo"<script>window.alert('Login to Continue');window.location.href='login.php';</script>";
     }



 $sql = "SELECT SUM(Price) AS totalPrice FROM tbl_cart WHERE cusID = $_SESSION[cusID] AND Payment='Pending';";
         $result = mysqli_query($connection,$sql);
         $row = mysqli_fetch_assoc($result); 
         $sum = $row['totalPrice'];


        $item="SELECT count(productID) as totalItem FROM tbl_cart WHERE cusID='$_SESSION[cusID]' AND Payment='Pending'";
	    $result=mysqli_query($connection,$item);
	    $row=mysqli_fetch_assoc($result);
        $items = $row['totalItem'];
?>

<form action="action.php" method="POST" id="checkoutForm">
    <h1 class="text-center">Checkout Form</h1>
    <div class="form-group" hidden>
        <label for="Name">Name</label>
        <input type="text" value="<?= $_SESSION['cusID']; ?>" name="cusID" class="form-control">
    </div>
    <div class="form-group">
        <label for="Name">Name</label>
        <input type="text" value="<?= $_SESSION['Name']; ?>" name="Name" class="form-control">
    </div>
    <div class="form-group">
        <label for="Address">Address</label>
        <input type="text" value="<?= $_SESSION['Address']; ?>" name="Address" class="form-control">
    </div>
    <div class="form-group">
        <label for="Contact">Contact No</label>
        <input type="text" value="<?= $_SESSION['ContactNo']; ?>" name="Contact" class="form-control">
    </div>
    <div class="form-group">
        <label for="totalItem">Total Item</label>
        <input type="text" value="<?= $items; ?>" class="form-control" name="TotalItem" readonly>
    </div>
    <div class="form-group">
        <label for="totalPrice">Total Price</label>
        <input type="text" value="<?= $sum; ?>" class="form-control" name="TotalPrice" readonly>
    </div>
    <div class="form-group">
        <label for="PaymentType">Payment Type</label>
        <select name="PaymentType" class="form-control form-select select" required> 
        <option  disabled value selected>Select Payment Type</option>
        <option value='AMEX'>American Express</option>
        <option value='Master'>Master</option>
        <option value='Visa'>Visa</option>
        <option value='PayPal'>PayPal</option>
    </select>
    </div>
    <div class="form-group">
        <label for="cardNo">Card No</label>
        <input type="text" minlength="16" maxlength="16"  class="form-control" name="CardNo" required>
    </div>

    <div class="form-group">
        <button type="submit" name="btncheckout" class="btn btn-warning form-control mt-3 mb-3">Checkout</button>
    </div>
</form>

<?php
 include 'function/footer.php';

 ?>