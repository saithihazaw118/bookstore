<?php
include("function/header.php");
include("function/connection.php");

$ISBN = $_GET['ISBN'];
$query     = "SELECT * FROM tbl_genre INNER JOIN tbl_book ON tbl_genre.genreID = tbl_book.genreID WHERE ISBN='$ISBN'";
$result = mysqli_query($connection, $query);
while ($rows=mysqli_fetch_assoc($result)) {
    $productid = $rows['productID'];
    $image = $rows['Image'];
    $title = $rows['bookTitle'];
    $price = $rows['Price'];
    $isbn = $rows['ISBN'];
    $genre = $rows['genre'];
    $author = $rows['Author'];
    $publisher = $rows['Publisher'];
    $Summary = $rows['Summary']; ?>

<div class="container">
    <div class="bookDisplay">
        <div class="row">
            <div class="img-row col-md-6"> 
            <img src="<?= $image; ?>" class="img-responsive"></div>
            <div class="col-md-6 bookdetail">
            <h2>Book Details</h2>
            <p><?= $Summary; ?></p>
            <ul>
                <li><b>Book Title :</b> <?= $title; ?></li>
                <li><b>Price      :</b> <?= '$'.$price; ?></li>
                <li><b>ISBN       :</b> <?= $isbn; ?></li>
                <li><b>Genre      :</b> <?= $genre; ?></li>
                <li><b>Author     :</b> <?= $author; ?></li>
                <li><b>Publisher  :</b> <?= $publisher; ?></li>
            </ul>
            </div>
        </div>
    </div>
    <form action="action.php" method="GET">
<input type="text" value="<?= $_SESSION['cusID'] ?>" name="cusID" hidden>
<input type="text" value="<?= $productid ?>" name="productID" hidden>
<input type="text" value="<?= $image ?>" name="image" hidden>
<input type="text" value="<?= $title ?>" name="title" hidden>
<input type="text" value="<?= $price ?>" name="price" hidden>
<input type="text" value="Pending" name="payment" hidden>
<button type="submit" name="add_to_cart" style="width: 50%;" class="btn btn-primary d-block mx-auto mb-3 form-control">Add to Cart</button>
</form>
</div>

<?php
}
include("function/footer.php");
?>
