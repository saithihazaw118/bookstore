<?php
	session_start();
	include "function/connection.php"; 
?>

<!DOCTYPE html>
<html lang="en"> 
<head>
  <title>Admin Approve and Edit Page</title> 
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
 <!-- Custom Css -->
 <link rel="stylesheet" type="text/css" href="css/style.css"> 
</head>
<body>
<nav class="navbar_sec">
	<header data-text="Admin_Home" class="admin-text">Admin Home</header>
	<ul class="ul-sec">
		<li class="li-sec"> <a href="approvenedit.php" class="nav-link">Approve</a>  </li>
		<li class="li-sec"> <a href="addproduct.php" class="nav-link">Add Product</a> </li>
		<li class="li-sec"> <a href="productdatatable.php" class="nav-link">View Product</a> </li>
		<li class="li-sec"> <a href="addgenre.php" class="nav-link">Add Genre</a> </li>
		<li class="li-sec"> <a href="query.php" class="nav-link">Query</a> </li>
		<li class="li-sec"> <a href="login.php" class="nav-link">Logout</a> </li>
	</ul>
</nav>

<main id="main-doc">
	<section class="main-section" id="Introduction">
	<header class="headerforcus"><h2>Customer Register Approve & Edit</h2></header>

<div class="container-sec">
  <!-- Trigger the modal with a button -->
  <div class="modal-button">
	<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">User Approve</button>

	<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#theirmodal">User Edit / Delete</button>
  </div>
  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-dialog-scrollable modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"></h4>
        </div>
        <div class="modal-body">
			<div class="center" >
			<!-- php strated -->
		<?php 
		$query = "SELECT * FROM tbl_customer WHERE status = 'pending' ORDER BY cusID ASC";
 		
 		$data=mysqli_query($connection,$query);
 		 $total=mysqli_num_rows($data); 


 		if ($total !=0)  
 		{
 			?>

		<table class="table1">
			<tr class="tr1" style="text-align: center;">
				<th class="th1" style="text-align: center;">Customer ID</th>
				<th class="th1" style="text-align: center;">Customer Name</th>
				<th class="th1" style="text-align: center;">Address</th>
				<th class="th1" style="text-align: center;">Contact Number</th>
				<th class="th1" style="text-align: center;">Email</th>
				<th class="th1" style="text-align: center;">Status</th>
				<th class="th1" style="text-align: center;" colspan="2">Action</th>
			</tr>

 		<?php 

 		while ($result=mysqli_fetch_assoc($data))
			 { 

 			echo " 
 				<tr class = 'tr1';>
 						<td>".$result['cusID']."</td>
 						<td>".$result['Name']."</td>
						 <td>".$result['Address']."</td>
						 <td>".$result['ContactNo']."</td>
 						<td>".$result['Email']."</td>
 						<td>".$result['Status']."</td>
						<td><a style='background-color: cadetblue;' href='function/approve.php?cusID=$result[cusID]'>Approve</a></td>
						<td><a style='background-color: red;' href='function/deny.php?cusID=$result[cusID]'>Deny</a></td>
 				</tr>  " ;
 		}
 			
	} 
	?>

</table>
	</div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
</div>


  <!-- Modal -->
  <div class="modal fade" id="theirmodal" role="dialog">
    <div class="modal-dialog modal-dialog-scrollable modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"></h4>
        </div>
        <div class="modal-body">
		<?php
	$query="SELECT * FROM tbl_customer WHERE status = 'approved'";
	$data=mysqli_query($connection,$query);
 	$total=mysqli_num_rows($data); 


		   if ($total !=0) 
 		{
 			?>

 		<table class="table1">
		<tr class="tr1" style="text-align: center;">
				<th class="th1" style="text-align: center;">Customer ID</th>
				<th class="th1" style="text-align: center;">Customer Name</th>
				<th class="th1" style="text-align: center;">Address</th>
				<th class="th1" style="text-align: center;">Contact Number</th>
				<th class="th1" style="text-align: center;">Email</th>
				<th class="th1" style="text-align: center;">Password</th>
				<th class="th1" style="text-align: center;" colspan="2">Action</th>
 		</tr>

 		<?php 

 		while ($result=mysqli_fetch_assoc($data))
			 {

 			echo " 
 			<tr class = 'tr1';>
						<td>".$result['cusID']."</td>
						<td>".$result['Name']."</td>
						<td>".$result['Address']."</td>
						<td>".$result['ContactNo']."</td>
						<td>".$result['Email']."</td>
						 <td><a style='background-color: cadetblue;' href='function/update.php?cusID=$result[cusID] & 
						 Name=$result[Name] &
						 Address=$result[Address] &
						 ContactNo=$result[ContactNo] &	
						 Email=$result[Email]'>Update</a></td>

						 <td><a style='background-color: red;' href='function/delete.php?cusID=$result[cusID] & 
						 Name=$result[Name] &
						 Address=$result[Address] &
						 ContactNo=$result[ContactNo] &	
						 Email=$result[Email]'>Delete</a></td>

						
 						
 				</tr>  " ;
 		}

 	}
	?>
	</table>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>

  


</section>
</main>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</body>
</html>