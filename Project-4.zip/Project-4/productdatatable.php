<?php
	session_start();
	include "function/connection.php"; 

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Product</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <!-- Custom Css -->
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<nav class="navbar_sec">
	<header data-text="Admin_Home" class="admin-text">Admin Home</header>
	<ul class="ul-sec">
		<li class="li-sec"> <a href="approvenedit.php" class="nav-link">Approve</a>  </li>
		<li class="li-sec"> <a href="addproduct.php" class="nav-link">Add Product</a> </li>
		<li class="li-sec"> <a href="productdatatable.php" class="nav-link">View Product</a> </li>
		<li class="li-sec"> <a href="addgenre.php" class="nav-link">Add Genre</a> </li>
        <li class="li-sec"> <a href="query.php" class="nav-link">Query</a> </li>
		<li class="li-sec"> <a href="login.php" class="nav-link">Logout</a> </li>
	</ul>
</nav>

<main id="main-doc">
	<section class="main-section" id="Introduction">
		<header><h2>View Product</h2></header>

 <div class="container mb-3 mt-3 scrollbar-modal">
        <table class="table table-scriped table-bordered mydatatable table1" style="width: 100%; text-align: center; position:relative; right: 150px; " id="mydatatable">

            <thead>
                <tr class="tr1">
                    <th class="th1">Product ID</th> 
                    <th class="th1">Image</th>
                    <th class="th1">Book Title</th>
                    <th class="th1">Price</th>
                    <th class="th1">IBSN</th>
                    <th class="th1" colspan="2">Active</th>
                </tr>
            </thead>

            <tbody>

				
			<?php
				$sqlimage  = "SELECT * FROM tbl_book";
				$imageresult1 = mysqli_query($connection,$sqlimage);
				
				while($rows=mysqli_fetch_assoc($imageresult1))
				{	
					$productid = $rows['productID'];
					$image = $rows['Image'];
					$title = $rows['bookTitle'];
					$price = $rows['Price'];
					$isbn = $rows['ISBN'];

					echo "<tr class = 'tr1';>";
					echo "<td>$productid</td>";
					echo "<td class = 'img1';><img src='$image'></td>";
					echo "<td>$title</td>";
					echo "<td>$$price</td>";
					echo "<td>$isbn</td>";
					echo "<td><a style='background-color: cadetblue;' href='productedit.php?productID=$rows[productID] &
                                                                            bookTitle=$rows[bookTitle] &
                                                                            image=$rows[Image] &
                                                                            Price=$rows[Price] &
                                                                            genreID=$rows[genreID] &
                                                                            ISBN=$rows[ISBN] &
                                                                            Author=$rows[Author] &
                                                                            Publisher=$rows[Publisher] &
                                                                            Summary=$rows[Summary]'>Edit</a></td> ";


					echo "<td><a style='background-color: red;' href='function/productdelete.php?productID=$rows[productID] &
														bookTitle=$rows[bookTitle] &
														image=$rows[Image] &
														Price=$rows[Price] &
														genreID=$rows[genreID] &
														ISBN=$rows[ISBN] &
														Author=$rows[Author] &
														Publisher=$rows[Publisher] &
														Summary=$rows[Summary]'>Delete</a></td> ";									
					
				
					echo "</tr>";

				} 
			?>
            </tbody>

            <tfoot>
            <tr class="tr1">
                    <th class="th1">Product ID</th>
                    <th class="th1">Image</th>
                    <th class="th1">Book Title</th>
                    <th class="th1">Price</th>
                    <th class="th1">IBSN</th>
                    <th class="th1" colspan="2">Active</th>
                </tr>
            </tfoot>

        </table>
        </section>

</main>
    </div>

    </section>
</main>

    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap4.min.js"></script>

    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

    <script>
        $('.mydatatable').DataTable({
            scrollY: 400,
            scrollX: true,
            scrollCollapse: true,
        });
    </script>
</body>
</html>

<!-- 
initcomplete: function() {
                this.api().columns().every ( function () {
                    var column = this;
                    var select = $('<select><option value = ""></option></select>')
                    .appendTo ( $(column.header()) .empty() )
                    .on('change', function() {
                        var val = $.fn.DataTable.util.escapeRegex(
                            $(this).val()
                        );

                        column 
                                .search( val ? '^'+val+'$' : '', true, false)
                                .draw();
                    });
                    column.data().unique().sort.each( function ( d, j ) {
                        select.append ('<option value="'+d+'">'+d+'</option>')
                    });
                });
            } -->