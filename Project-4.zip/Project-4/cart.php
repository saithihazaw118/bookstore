<?php
 include "function/header.php";
 include "function/connection.php";
 if(!isset($_SESSION['Email'])){
    echo"<script>window.alert('Login to Continue');window.location.href='login.php';</script>";
     }


?>
 <div class="container mb-3 mt-3 table-responsive">
     <!-- <form action="action.php" method="GET"> -->
 <table class="table table-striped table-bordered text-center "  id="mydatatable">

     <thead>
         <tr >
             <th hidden>Product ID</th>
             <th style="width: 30%;">Book Title</th>
             <th style="width: 30%;">Image</th>
             <th style="width: 10%;">Price</th>
             <th style="width: 10%;">Active</th>
         </tr>
     </thead>

     <tbody>

         
     <?php


         $sqlimage  = "SELECT * FROM tbl_cart WHERE cusID='$_SESSION[cusID]' AND Payment='Pending'";
         $imageresult1 = mysqli_query($connection,$sqlimage);
         
         $sql = "SELECT SUM(Price) AS totalPrice FROM tbl_cart WHERE cusID = $_SESSION[cusID] AND Payment='Pending';";
         $result = mysqli_query($connection,$sql);
         $row = mysqli_fetch_assoc($result); 
         $sum = $row['totalPrice'];


        $item="SELECT count(productID) as totalItem FROM tbl_cart WHERE cusID='$_SESSION[cusID]' AND Payment='Pending'";
	    $result=mysqli_query($connection,$item);
	    $row=mysqli_fetch_assoc($result);
        $items = $row['totalItem'];

         while($rows=mysqli_fetch_assoc($imageresult1))
         {	
             $productid = $rows['productID'];
             $title = $rows['bookTitle'];
             $image = $rows['Image'];

             $price = $rows['Price'];

             echo "<tr>";
             echo "<td hidden></td>";
             echo "<td>$title</td>";
             echo "<td><img src='$image' class='img-responsive cartImg' styles='max-width: 220px;'></td>";

             echo "<td>$price</td>";
             echo "<td><a href='removeItem.php?productID=$rows[productID]'><i class='fa-solid fa-trash-can'></i>Remove</a></td> ";
            echo "</tr>";

                                                } 

?>
<tr hidden>
        <td colspan="2">Total Item</td>
        <td colspan="2"><input type='text' value='<?=$items?>' name='totalItem' hidden><?= $items ?></td>
    </tr>
    <tr>
        <td colspan="2">Total</td>
        <td colspan="2"><input type='text' value='<?=$sum?>' name='total' hidden><?= '$'.$sum ?></td>
    </tr>
    <tr>
     <td colspan="4"><a href="checkout.php" class="btn btn-warning d-block">Checkout</a></td>
    </tr>
     </tbody>
     
     <!-- </form> -->



<?php
 include "function/footer.php";
?>