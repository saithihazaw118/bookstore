<?php
include("template/header.php");
?>
<!-- <script defer>
const aRegisterForm = getElementById("aRegisterForm");
const adminName = document.getElementById("ausername");
const adminEmail = document.getElementById("aemail");
const adminPassword = document.getElementById("apassword");
const adminCPassword = document.getElementById("acpassword");

let aName      = false;
let aEmail     = false;
let aPassword  = false;
let aCPassword = false;

aRegisterForm.addEventListener("submit", (e) => {
  AdminvalidateInputs();
  if (!(aName && aEmail && aPassword && aCPassword)) {
    e.preventDefault();
  } else {
    $(this).unbind("submit");
    e.currentTarget.submit();
  }
});

const setSuccess = (element) => {
  const formGroup = element.parentElement;
  const errorDisplay = formGroup.querySelector(".error");

  errorDisplay.innerText = "";
  formGroup.classList.add("success");
  formGroup.classList.remove("error");
};

  const isValidString = (username) => {
  const re = /^(?! )[A-Za-z\s]+$/;
  return re.test(String(username).toLowerCase());
};
const isValidEmail = (email) => {
  const re =
    /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test(String(email).toLowerCase());
};
const AdminvalidateInputs = () => {
  const adminNameValue = adminName.value.trim();
  const adminEmailValue = adminEmail.value.trim();
  const adminPasswordValue = adminPassword.value.trim();
  const adminCPasswordValue = adminCPassword.value.trim();
  
  const setError = (element, message) => {
  const formGroup = element.parentElement;
  const errorDisplay = formGroup.querySelector(".error");

  errorDisplay.innerText = message;
  formGroup.classList.add("error");
  formGroup.classList.remove("success");
};

  if (adminNameValue === "") {
    setError(adminName, "Name is required");
  } else if (!isValidString(adminNameValue)) {
    setError(adminName, "Letters and WhiteSpaces only");
  } else {
    setSuccess(adminName);
    aName = true;
  }

  if (adminEmailValue === "") {
    setError(adminEmail, "Email is required");
  } else if (!isValidEmail(adminEmailValue)) {
    setError(adminEmail, "Provide a valid email address");
  } else {
    setSuccess(adminEmail);
    aEmail = true;
  }

  if (adminPasswordValue === "") {
    setError(adminPassword, "Password is required");
  } else if (adminPasswordValue.length < 8) {
    setError(adminPassword, "Password must be at least 8 character.");
  } else {
    setSuccess(adminPassword);
    aPassword = true;
  }

  if (adminCPasswordValue === "") {
    setError(adminCPassword, "Please confirm your password");
  } else if (adminCPasswordValue !== adminPasswordValue) {
    setError(adminCPassword, "Passwords doesn't match");
  } else {
    setSuccess(adminCPassword);
    aCPassword = true;
  }
};
</script> -->
<div class="container">
<form action="action.php" method="POST" id="aRegisterForm">
   <div class="text-center text-primary mt-3">
   <h1>Admin Register Form</h1>
   </div>
   <div class="form-group mb-3">
        <label for="Name">Name:</label>
        <input type="text" name="Name" placeholder="Enter your Name" class="form-control" pattern="^(?! )[A-Za-z\s]+$" onkeypress="return /[a-z]/i.test(event.key)" required autofocus>

    </div>
   
    <div class="form-group mb-3">
        <label for="Email">Email:</label>
        <input type="email" name="Email" pattern="^[a-zA-Z0-9]+@gmail\.com$" placeholder="Enter email address" class="form-control" required>
    </div>
    <div class="form-group mb-3">
        <label for="Password">Password:</label>
        <input type="Password" name="Password"  placeholder="Enter Password" class="form-control" required>
    </div>

    <div class="form-group mb-3">
        <button type="submit" name="btnAdminRegister" class="btn btn-outline-primary form-control"><i class="fa-solid fa-arrow-right-to-bracket"></i> Register</button>
    </div>
    <hr>
    <div class="form-group text-center">
       <p>Already have an account ? Login <a href="Login.php">HERE</a></p>
    </div>
</form>

<?php
include("template/footer.php");
?>