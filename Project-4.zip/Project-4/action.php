<?php
session_start();
require('function/connection.php');

// Register

if (isset($_POST['btnRegister'])) {
    $name = htmlspecialchars($_POST['Name']);
    $address = htmlspecialchars($_POST['Address']);
    $contact = htmlspecialchars($_POST['Contact']);
    $email = htmlspecialchars($_POST['Email']);
    $password = htmlspecialchars(md5(($_POST['Password'])));
    $status = htmlspecialchars($_POST['Status']);

    // Check Unique Email
    $checkEmail = "SELECT * FROM tbl_customer WHERE Email = '$email'";
    $result     = mysqli_query($connection, $checkEmail);
    $count      = mysqli_num_rows($result);

    // Check contact no
    $checkContact  = "SELECT * FROM tbl_customer WHERE ContactNo= '$contact'";
    $contactResult = mysqli_query($connection, $checkContact);
    $contactCount  = mysqli_num_rows($contactResult);
    if ($count > 0) {
        echo "<script>alert('Email has already been taken.');window.location.href='Register.php';</script>";
    } elseif ($contactCount > 0) {
        echo "<script>alert('Contact has already been taken.');window.location.href='Register.php';</script>";
    } else {
        $dbquery = "INSERT INTO tbl_customer (Name, Address , ContactNo , Email , Password , Status) 
        VALUES('$name', '$address', '$contact' , '$email' , '$password', '$status') ";

        $dataquery = mysqli_query($connection, $dbquery);
        if ($dataquery) {
            echo "<script>alert('Registration successful, Please standby for Account Review');window.location.href='Login.php';</script>";
        } else {
            mysqli_error($connection);
        }
    }
}

//Admin Register

if (isset($_POST['btnAdminRegister'])) {
    $name = htmlspecialchars($_POST['Name']);
    $email = htmlspecialchars($_POST['Email']);
    $password = htmlspecialchars(md5(($_POST['Password'])));

    // Check Unique Email
    $checkEmail = "SELECT * FROM tbl_admin WHERE adminEmail = '$email'";
    $result     = mysqli_query($connection, $checkEmail);
    $count      = mysqli_num_rows($result);

    if ($count > 0) {
        echo "<script>alert('Email has already been taken.');window.location.href='Register.php';</script>";
    } else {
        $dbquery = "INSERT INTO tbl_admin (adminName, adminEmail , adminPassword) 
        VALUES('$name', '$email' , '$password') ";

        $dataquery = mysqli_query($connection, $dbquery);
        if ($dataquery) {
            echo "<script>alert('Registration successful, Redirecting...');window.location.href='Login.php';</script>";
        } else {
            mysqli_error($connection);
        }
    }
}

// Login

if(isset($_POST['btnLogin'])){
    $email    =  htmlspecialchars($_POST['Email']);
    $password =  htmlspecialchars(md5($_POST['Password']));
    // User
    $checkStatus = "SELECT * FROM tbl_customer WHERE Email = '$email' && Status ='Approved'";
    $statusResult = mysqli_query($connection, $checkStatus);
    
     // Admin
     $query         = "SELECT * FROM tbl_admin WHERE adminEmail = '$email'";
     $loginResult   = mysqli_query($connection, $query);

    if (mysqli_num_rows($statusResult)>0) {
        while ($row   = mysqli_fetch_assoc($statusResult)) {
            $dbcusID = $row['cusID'];
            $dbname  = $row['Name'];
            $dbAddress = $row['Address'];
            $dbContactNo = $row['ContactNo'];
            $dbemail = $row['Email'];
            $dbpass  = $row['Password'];
        }
        if ($email === $dbemail && $password === $dbpass) {
            $_SESSION['cusID' ]=$dbcusID;
            $_SESSION['Email']=$dbemail;
            $_SESSION['Name']=$dbname;
            $_SESSION['Address']=$dbAddress;
            $_SESSION['ContactNo']=$dbContactNo;
             
            echo "<script>alert('Welcome $dbname.');window.location.href='index.html';</script>";
        }else {
            echo "<script>alert('Email and Password does not match.');window.location.href='Login.php'</script>";
        }
    }else  if (mysqli_num_rows($loginResult)>0) {
        while ($row   = mysqli_fetch_assoc($loginResult)) {
            $dbadminID = $row['adminID'];
            $dbname  = $row['adminName'];
            $dbemail = $row['adminEmail'];
            $dbpass  = $row['adminPassword'];
        }
        if ($email === $dbemail && $password === $dbpass) {
            $_SESSION['adminID' ]=$dbadminID;
            $_SESSION['adminEmail']=$dbemail;
            $_SESSION['adminName']=$dbname;
             
            echo "<script>alert('Welcome $dbname.');window.location.href='approvenedit.php';</script>";
        } else {
            echo "<script>alert('Email and Password does not match.');window.location.href='../index.html'</script>";
        }
    } else{
        echo "<script>alert('Account yet to be Approved.');window.location.href='Login.php'</script>";
    } 
}

//add genre
if(isset($_POST['btngenre'])) {
    $genre = $_POST['genre'];
    $select = "SELECT genre FROM tbl_genre WHERE genre = '$genre'";

    $result = mysqli_query($connection,$select);
    $count=mysqli_num_rows($result);

    if($count > 1) {
        echo "<script>window.alert('This category is already exists')</script>";
        echo "<script>window.location='approvenedit.php'</script>";
    }else {

    $add = "INSERT INTO tbl_genre (genre)
     VALUES ('$genre')";
     mysqli_query($connection,$add);
    echo "<script>window.alert('Product title inserted.')</script>";
    echo "<script>window.location='addgenre.php'</script>";
    }
}


// Cart
if(isset($_GET['add_to_cart'])){
    $cusID = htmlspecialchars($_GET['cusID']);
    $productid = htmlspecialchars($_GET['productID']);
    $title = htmlspecialchars($_GET['title']);
    $img = htmlspecialchars($_GET['image']);
    $price = htmlspecialchars($_GET['price']);
    $payment = htmlspecialchars($_GET['payment']);

    $select = "SELECT * FROM tbl_cart WHERE cusID = '$cusID' AND productID='$productid'";

    $result = mysqli_query($connection,$select);
    $count=mysqli_num_rows($result);

    if($count > 1) {
        echo "<script>window.alert('Product exists')</script>";
        echo "<script>window.location='category.php'</script>";
    }else {

    $add = "INSERT INTO tbl_cart(cusID,productID,bookTitle,Image,Price,Payment)
     VALUES ('$cusID','$productid','$title','$img','$price','$payment')";
     mysqli_query($connection,$add);
    echo "<script>window.alert('Added to cart')</script>";
    echo "<script>window.location='category.php'</script>";
    }
}

// Checkout 

if(isset($_POST['btncheckout'])){
    $cusID = htmlspecialchars($_POST['cusID']);
    $name  = htmlspecialchars($_POST['Name']);
    $address  = htmlspecialchars($_POST['Address']);
    $contact  = htmlspecialchars($_POST['Contact']);
    $totalItem  = htmlspecialchars($_POST['TotalItem']);
    $totalPrice  = htmlspecialchars($_POST['TotalPrice']);
    $PaymentType  = htmlspecialchars($_POST['PaymentType']);
    $Card  = htmlspecialchars($_POST['CardNo']);


    $add = "INSERT INTO tbl_order (cusID,Name,Address,ContactNo,total_item,total_price,payment_type,card_no)
             VALUES ('$cusID','$name','$address','$contact','$totalItem','$totalPrice','$PaymentType','$Card')";
     $query = mysqli_query($connection,$add);
     if($query){
    echo "<script>window.alert('Order Successful')</script>";
    echo "<script>window.location='updatePayment.php?cusID=$cusID'</script>";
     }else{
        mysqli_error($connection);
     }
}