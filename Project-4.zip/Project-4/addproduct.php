<?php
	session_start();
	include "function/connection.php"; 

		
if(isset($_POST['btnsubmit'])) {
    $booktitle = $_POST['booktitle'];
    $image = $_FILES['image'];
    $price = $_POST['price'];
	$genre = $_POST['genre'];
	$isbn = $_POST['isbn'];
	$author = $_POST['author'];
	$publisher = $_POST['publisher'];
	$summary = $_POST['summary']; 

	$img_path='images/'.$image['name'];

		if(!is_uploaded_file($image['tmp_name'])) 
		{
			$error[]="Product Image is required";
		}

    $select = "SELECT * FROM tbl_book WHERE ISBN = '$isbn'";
    $result = mysqli_query($connection,$select);
    $count=mysqli_num_rows($result);

    if($count > 0) {
        echo "<script>window.alert('This book is already exists')</script>";
        echo "<script>window.location='approvenedit.php'</script>";
    }else {
		move_uploaded_file($image['tmp_name'], $img_path);

        $btnsubmit	 = "INSERT INTO tbl_book(bookTitle, Image, Price, genreID, ISBN, Author, Publisher, Summary)
        VALUES ('$booktitle','$img_path','$price','$genre','$isbn','$author','$publisher','$summary')";
        $result1 =  mysqli_query($connection,$btnsubmit);

        if ($result1) 
        {
			echo "<script>window.alert('Product Inserted Successful.')
			window.location='addproduct.php'</script>";
   		}
      else
       {
         mysqli_error($connection);
       }

    }

}
	?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Product Add Page</title> 
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<!-- Custom Css -->
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<nav class="navbar_sec">
	<header data-text="Admin_Home" class="admin-text">Admin Home</header>
	<ul class="ul-sec">
		<li class="li-sec"> <a href="approvenedit.php" class="nav-link">Approve</a>  </li>
		<li class="li-sec"> <a href="addproduct.php" class="nav-link">Add Product</a> </li>
		<li class="li-sec"> <a href="productdatatable.php" class="nav-link">View Product</a> </li>
		<li class="li-sec"> <a href="addgenre.php" class="nav-link">Add Genre</a> </li>
		<li class="li-sec"> <a href="query.php" class="nav-link">Query</a> </li>
		<li class="li-sec"> <a href="login.php" class="nav-link">Logout</a> </li>
	</ul>
</nav>

<main id="main-doc">
	<section class="main-section" id="Introduction">
		<header><h2>Add Product</h2></header>
		<div class="center">
		<form action="addproduct.php" method="POST" enctype="multipart/form-data">

		<div class="form-group row ">
            <label for="booktitle" class="col-sm-2 col-form-label">Book Title</label>
			<div class="col-sm-10">
           		<input type="text" class="form-control" name="booktitle" required>
			</div>
		</div>


		<div class="form-group row ">
            <label for="image" class="col-sm-2 col-form-label">Image</label>
			<div class="col-sm-10">
				<input type="file" name="image" class="form-control" accept="image/*">
			</div>
		</div>

		<div class="form-group row ">
			<label for="price" class="col-sm-2 col-form-label">Price</label>
			<div class="col-sm-10">
            	<input type="text" name="price" placeholder="$0.00" class="form-control" required>
			</div>
		</div>

		<div class="form-group row">		
            <label for="genre" class="col-sm-2 col-form-label">Genre</label>
			<div  class="col-sm-10">
				<select name="genre"  class="form-select form-control"  required>
						<option required="---Select Category---" >---Select Category---</option>
						<?php 
							$select="SELECT * FROM tbl_genre ";
							$run=mysqli_query($connection,$select);
							$count=mysqli_num_rows($run);

							for($i=0;$i<$count;$i++)
							{
								$data=mysqli_fetch_array($run);
								$genreID=$data['genreID'];
								$genre=$data['genre'];

								echo "<option value='$genreID'>".$genre."</option>";
							}
							?>
						
				</select>
			</div>
		</div>


		<div class="form-group row ">
			<label for="isbn" class="col-sm-2 col-form-label">ISBN</label>
			<div class="col-sm-10">
            	<input type="text" name="isbn" class="form-control" required>
			</div>
		</div>

		<div class="form-group row ">
            <label for="author" class="col-sm-2 col-form-label">Author</label>
			<div class="col-sm-10">
            	<input type="text" name="author" class="form-control" required>
			</div>
		</div>

		<div class="form-group row ">
			<label for="publisher" class="col-sm-2 col-form-label">Publisher</label>
			<div class="col-sm-10">
            	<input type="text" name="publisher" class="form-control" required>
			</div>
		</div>

		<div class="form-group row ">
            <label for="summary" class="col-sm-2 col-form-label">Summary</label>
			<div class="col-sm-10">
				<textarea type="text" name="summary" class="form-control" cols="30" rows="10"></textarea>
			</div>
		</div>

		<div>
			<button type="submit" name="btnsubmit" class="form-control btn btn-primary">Submit</button>
		</div>

            
        </form>
		</div>
	</section>

</main>


</body>
</html>