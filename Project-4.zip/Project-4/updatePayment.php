
  <?php
  include ('function/connection.php'); 
$cusID = $_GET['cusID']; 

$updatePayment = mysqli_query($connection,"UPDATE tbl_cart SET Payment = 'Paid' WHERE cusID='$cusID'"); 

if($updatePayment)
{
    mysqli_close($connection); 
    echo "<script>alert('Payment Success! , Redirecting');window.location.href='orderHistory.php';</script>";
}
else
{
    echo "<script>alert('Payment Error! , Try Again');window.location.href='checkout.php';</script>";
}


?>