<?php 
session_start();

include "function/connection.php"; 

$productid=$_GET['productID'];
echo "$productid";
// $_GET['bookTitle'];
$img = $_GET['image'];
// $_GET['Price'];
// $_GET['genreID'];
// $_GET['ISBN'];
// $_GET['Author'];
// $_GET['Publisher'];
// $_GET['Summary'];




if(isset($_GET['update']))
{
    $productID=$_GET['productID'];
    $bookTitle=$_GET['booktitle'];
    $image = $_GET['image'];
    $Price=$_GET['price'];
    $genreID=$_GET['genre'];
    $ISBN=$_GET['isbn'];
    $Author=$_GET['author'];
    $Publisher=$_GET['publisher'];
    $Summary=$_GET['summary'];
    // $error=[];


   
    if(!is_uploaded_file($image)) 
    {

        $img_path='images/'.$image;
        move_uploaded_file($image, $img_path);

        $query = "UPDATE tbl_book SET   bookTitle='$bookTitle',
                                        Image='$img_path',
                                        Price='$Price',
                                        genreID='$genreID',
                                        ISBN='$ISBN',
                                        Author='$Author',
                                        Publisher='$Publisher',     
                                        summary='$Summary'
                                        WHERE productID='$productID' ";
    
    $data=mysqli_query($connection,$query);
    if ($data)
    {
      echo "<script>window.alert('Update Successful')</script>";
     echo "<script>window.location='productdatatable.php'</script>";
    }  
    
    else
    {
      echo "<font color='red'>Update Failed,Try Again </font> ";
    }
    }
    
    
    }
    
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Product Edit</title> 
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<!-- Custom Css -->
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<nav class="navbar_sec">
	<header data-text="Admin_Home" class="admin-text">Admin Home</header>
	<ul class="ul-sec">
		<li class="li-sec"> <a href="approvenedit.php" class="nav-link">Approve</a>  </li>
		<li class="li-sec"> <a href="addproduct.php" class="nav-link">Add Product</a> </li>
		<li class="li-sec"> <a href="productdatatable.php" class="nav-link">View Product</a> </li>
		<li class="li-sec"> <a href="addgenre.php" class="nav-link">Add Genre</a> </li>
		<li class="li-sec"> <a href="login.php" class="nav-link">Logout</a> </li>
	</ul>
</nav>

<main id="main-doc">
	<section class="main-section" id="Introduction">
    <header><h2>Product Edit</h2></header>

    <div class="center">

        <form action="productedit.php" method="GET" enctype="multipart/form-data">
        <input type="hidden" name="productID" value="<?php echo $_GET['productID']; ?>" >

        <div class="form-group row ">
            <label for="booktitle" class="col-sm-2 col-form-label">Book Title</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name="booktitle" value="<?php echo $_GET['bookTitle']; ?>" >
            </div>
            </div>

        <div class="form-group row ">
            <label for="image" class="col-sm-2 col-form-label">Image</label>
            <div class="col-sm-10">
                <input type="file" class="form-control" name="image" accept="image/*">
                <img src="<?php echo $_GET['Image']; ?>" alt="" style="width: 100px; height: 100px; object-fit: cover; border:1px solid red;">
                </div>
            </div>

        <div class="form-group row ">   
            <label for="price" class="col-sm-2 col-form-label">Price</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name="price" value="<?php echo $_GET['Price']; ?>" >
                </div>
            </div>

            <div class="form-group row">
                <label for="genreid" class="col-sm-2 col-form-label">Genre</label>
                <div  class="col-sm-10">
                    <select name="genre"  required  class="form-select form-control">

                            <?php  $select="SELECT * FROM tbl_genre g, tbl_book b
                            WHERE g.genreID = b.genreID ";
                                $run=mysqli_query($connection,$select);
                                $count=mysqli_num_rows($run);

                                                            
                                while ($result=mysqli_fetch_assoc($run))
                                {   
                                    $genreID= $result['genreID'];
                                    $genre= $result['genre'];

                                    echo "<option value='$genreID'>".$genre."</option>";
                                } ?>

                            <?php 
                                $select="SELECT * FROM tbl_genre ";
                                $run=mysqli_query($connection,$select);
                                $count=mysqli_num_rows($run);

                                for($i=0;$i<$count;$i++)
                                {
                                    $data=mysqli_fetch_array($run);
                                    $genreID=$data['genreID'];
                                    $genre=$data['genre'];
                                
                                    echo "<option value='$genreID'>".$genre."</option>";
                                }
                                ?>
                            
                    </select>
                    </div>
		        </div>

                
            <div class="form-group row ">  
            <label for="isbn" class="col-sm-2 col-form-label">ISBN</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name="isbn" value="<?php echo $_GET['ISBN']; ?>" >
                </div>
            </div>  

            <div class="form-group row ">             
            <label for="author" class="col-sm-2 col-form-label">Author</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name="author" value="<?php echo $_GET['Author']; ?>" >
                </div>
            </div>

            <div class="form-group row "> 
            <label for="publisher" class="col-sm-2 col-form-label">Publisher</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name="publisher" value="<?php echo $_GET['Publisher']; ?>" >
                </div>
            </div>

            <div class="form-group row ">
            <label for="summary" class="col-sm-2 col-form-label">Summary</label>
            <div class="col-sm-10">   
                <input type="passwrod" class="form-control" name="summary" value="<?php echo $_GET['Summary']; ?>" cols="30" rows="10" >
                </div>
            </div>

            <div>
                <input style="background-color: rgb(18, 22, 18); color:white; border-radius: 3px; width: 90px" type="submit" name="update" value="Update">
                <a href="editproduct.php">Back</a>
            </div> 

        </form>
    </div>
    </section>

</main>
</body>
</html>