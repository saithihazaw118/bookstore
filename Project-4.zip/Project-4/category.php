<?php
include("function/header.php");
include("function/connection.php");

if(!isset($_SESSION['Email'])){
  echo"<script>window.alert('Login to Continue');window.location.href='login.php';</script>";
   }

?>

<!-- Genre Display Function -->
<?php
    function displayProduct($genre)
    {
        include("function/connection.php");
        $query  = "SELECT * FROM tbl_genre INNER JOIN tbl_book ON tbl_genre.genreID = tbl_book.genreID WHERE genre='$genre' ";
        $result = mysqli_query($connection, $query);
      
        while ($rows=mysqli_fetch_assoc($result)) {
            $productid = $rows['productID'];
            $image = $rows['Image'];
            $title = $rows['bookTitle'];
            $price = $rows['Price'];
            $isbn = $rows['ISBN'];
            $genre = $rows['genre']; ?>

<div class="col-lg-4 d-flex product-card card text-center" style="width: 18rem;" >

<img src="<?=$image ?>" class="img-responsive">
<div class="card-body">
<?php
   echo "<a href='productDetail.php?ISBN=$rows[ISBN]'><h5 class='card-title mb-3'> $title</h5></a>"
  ?>
 <p class="card-text"><?= '$'.$price ?></p>
 <span class="genre" hidden><?= $genre ?></span>

 <form action="action.php" method="GET" >
 <input type="text" value="<?= $_SESSION['cusID'] ?>" name="cusID" hidden>
<input type="text" value="<?= $productid ?>" name="productID" hidden>
<input type="text" value="<?= $title ?>" name="title" hidden>
<input type="text" value="<?= $price ?>" name="price" hidden>
<input type="text" value="Pending" name="payment" hidden>
<button type="submit" name="add_to_cart" class="btn btn-primary form-control">Add to Cart</button>
</form>
 <?php
 
  // echo "<a href='cartItem.php?productID=$rows[productID] & image=$rows[Image] & title=$rows[bookTitle] & price=$rows[Price] & ISBN=$rows[ISBN]' class='btn btn-primary form-control' name='btnAddToCart'>Add to cart</a>"; ?>

</div>
</div>
    
<?php
        };
    }; ?>
<div class="container">
<div class="tab text-center mt-3 mb-3">
  <button class="tablinks btn btn-secondary" name="showall" onclick="displayProduct(event, '*')">Show All</button>
  <button class="tablinks btn btn-secondary" name="horror"  onclick="displayProduct(event, 'Horror')">Horror</button>
  <button class="tablinks btn btn-secondary" onclick="displayProduct(event, 'Romance')">Romance</button>
  <button class="tablinks btn btn-secondary" onclick="displayProduct(event, 'Fiction')">Fiction</button>
  <button class="tablinks btn btn-secondary" onclick="displayProduct(event, 'Non-Fiction')">Non-Fiction</button>
  <button class="tablinks btn btn-secondary" onclick="displayProduct(event, 'Novel')">Novel</button>
</div>
</div>

<div id="*" class="tabcontent text-center">
  <h3>All Product</h3>
  
<div class="container-fluid" id="product">
  <div class="row d-flex flex-wrap justify-content-evenly mt-5">
  <?php
      include("function/connection.php");
      $query  = "SELECT * FROM tbl_genre INNER JOIN tbl_book ON tbl_genre.genreID = tbl_book.genreID";
      $result = mysqli_query($connection, $query);
    
      while ($rows=mysqli_fetch_assoc($result)) {
          $productid = $rows['productID'];
          $image = $rows['Image'];
          $title = $rows['bookTitle'];
          $price = $rows['Price'];
          $isbn = $rows['ISBN'];
          $genre = $rows['genre']; ?>

<div class="col-lg-4 d-flex product-card card text-center" style="width: 18rem;" >

<img src="<?=$image ?>" class="img-responsive">
<div class="card-body">
<?php
   echo "<a href='productDetail.php?ISBN=$rows[ISBN]'><h5 class='card-title mb-3'> $title</h5></a>"
  ?>

<p class="card-text"><?= '$'.$price ?></p>
<span class="genre" hidden><?= $genre ?></span>
<form action="action.php" method="GET">
<input type="text" value="<?= $_SESSION['cusID'] ?>" name="cusID" hidden>
<input type="text" value="<?= $productid ?>" name="productID" hidden>
<input type="text" value="<?= $title ?>" name="title" hidden>
<input type="text" value="<?= $image ?>" name="image" hidden>
<input type="text" value="<?= $price ?>" name="price" hidden>
<input type="text" value="Pending" name="payment" hidden>
<button type="submit" name="add_to_cart" class="btn btn-primary form-control">Add to Cart</button>
</form>
<?php
  // echo "<a href='cartItem.php?productID=$rows[productID] & image=$rows[Image] & title=$rows[bookTitle] & price=$rows[Price] & ISBN=$rows[ISBN]'class='btn btn-primary form-control'>Add to cart</a>"; 
  ?>
</div>
</div>
  
<?php
      };
       ?>
  </div>
  </div>
</div>


<!-- horror section -->
<div id="Horror" class="tabcontent  text-center mt-3 mb-3">
  <h3>Horror Category</h3>
  
<div class="container-fluid" id="product">
  <div class="row d-flex flex-wrap justify-content-evenly mt-5">
    
    <?php
       displayProduct("horror");
       ?>
  </div>
  </div>
</div>
<!-- romance section -->
<div id="Romance" class="tabcontent  text-center mt-3 mb-3">
  <h3>Romance Book</h3>
 
<div class="container-fluid" id="product">
  <div class="row d-flex flex-wrap justify-content-evenly mt-5">
     <?php
     displayProduct("Romance");
     ?>
  </div>
  </div>
</div>
<!-- Fiction -->
<div id="Fiction" class="tabcontent  text-center mt-3 mb-3">
  <h3>Fiction Book</h3>
 
<div class="container-fluid" id="product">
  <div class="row d-flex flex-wrap justify-content-evenly mt-5">
  <?php
     displayProduct("Fiction");
     ?>
  </div>
  </div>
</div>

<!-- Non Fiction -->
<div id="Non-Fiction" class="tabcontent  text-center mt-3 mb-3">
  <h3>Non-Fiction Book</h3>
 
<div class="container-fluid" id="product">
  <div class="row d-flex flex-wrap justify-content-evenly mt-5">
  <?php
     displayProduct("Non-Fiction");
     ?>
  </div>
  </div>
</div>
<div id="Novel" class="tabcontent text-center mt-3 mb-3">
  <h3>Novel Book</h3>
 
<div class="container-fluid" id="product">
  <div class="row d-flex flex-wrap justify-content-evenly mt-5">
  <?php
     displayProduct("Novel");
     ?>
  </div>
  </div>
</div>


<script>
function displayProduct(evt, genre) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(genre).style.display = "block";
  evt.currentTarget.className += " active";
}
</script>
<?php

include("function/footer.php");
?>


