<?php
session_start();
include 'function/connection.php';

$productid = $_GET['productID']; 

$del = mysqli_query($connection,"DELETE FROM tbl_cart  WHERE productID='$productid'"); 

if($del)
{
    mysqli_close($connection); 
    echo "<script class='text-danger'>alert('Item Removed!');window.location.href='cart.php';</script>";
}
else
{
    echo "Error removing item"; 
}