<?php
include("function/header.php");
?>

<div class="container">
<form action="action.php" method="POST" id="registerForm" >
   <div class="text-center text-primary mt-3">
   <h1>Register Form</h1>
   </div>
   <div class="form-group mb-3">
        <label for="Name">Name:</label>
        <input type="text" id="username" name="Name" placeholder="Enter your Name" class="form-control" autofocus>
        <div class="error text-danger"></div>
    </div>
    <div class="form-group mb-3">
        <label for="Address">Address:</label>
        <textarea name="Address" id="address" cols="30" rows="3" class="form-control" placeholder="Enter your address"></textarea>
        <div class="error text-danger"></div>
    </div>
    <div class="form-group mb-3">
        <label for="Contact">Contact No:</label>
       <input name="Contact" type="tel" id="contact" placeholder="Enter your contact no" class="form-control">
       <div class="error text-danger"></div>
    </div>
    <div class="form-group mb-3">
        <label for="Email">Email:</label>
        <input type="email" name="Email" id="email" placeholder="Enter email address" class="form-control">
        <div class="error text-danger"></div>
    </div>
    <div class="form-group mb-3">
        <label for="Password">Password:</label>
        <input type="Password" name="Password" id="password" placeholder="Enter Password" class="form-control">
        <div class="error text-danger"></div>
    </div>
    <div class="form-group mb-3">
        <label for="CPassword">Confirm Password:</label>
        <input type="Password" name="CPassword" id="cpassword" placeholder="Confirm Password" class="form-control">
        <div class="error text-danger"></div>
    </div>
    <div class="form-group mb-3" hidden >
        <label for="Status">Status:</label>
        <input type="text" name="Status" value="Pending" class="form-control">
        <div class="error text-danger"></div>
    </div>
    <div class="form-group mb-3">
        <button type="submit" name="btnRegister" class="btn btn-outline-primary form-control"><i class="fa-solid fa-arrow-right-to-bracket"></i> Register</button>
    </div>
    <hr>
    <div class="form-group text-center">
       <p>Already have an account ? Login <a href="Login.php">HERE</a></p>
    </div>
</form>
</div>

<?php
include("function/footer.php");
?>